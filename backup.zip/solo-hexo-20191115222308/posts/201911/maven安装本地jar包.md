title: maven安装本地jar包
date: '2019-11-14 09:49:33'
updated: '2019-11-14 09:49:33'
tags: [maven]
permalink: /articles/2019/11/14/1573696172937.html
---
![](https://img.hacpai.com/bing/20191009.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

安装命令
```shell
mvn install:install-file -DgroupId=<your_group_name>  -DartifactId=<your_artifact_name> -Dversion=<snapshot>  -Dfile=<path_to_your_jar_file> -Dpackaging=jar -DgeneratePom=true 
```

添加依赖关系
```xml
<dependency>
    <artifactId>xxx</artifactId>
    <groupId>xxx</groupId>
    <version>xxx</version>
</dependency>
```

